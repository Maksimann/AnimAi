(function () {
  const t = i18n.t;
  const app = document.getElementById('app');
  const listEl = document.getElementById('characterList');
  const messagesEl = document.getElementById('messages');
  const form = document.getElementById('composer');
  const input = document.getElementById('input');
  const sendBtn = document.getElementById('sendBtn');
  const clearBtn = document.getElementById('clearBtn');
  const backBtn = document.getElementById('backBtn');
  const headerAvatar = document.getElementById('headerAvatar');
  const headerName = document.getElementById('headerName');
  const headerTagline = document.getElementById('headerTagline');

  let characters = [];
  let current = null;
  let sending = false;

  // История хранится в браузере пользователя, отдельно для каждого персонажа
  const storageKey = (id) => 'chat:' + id;
  function loadHistory(id) {
    try {
      const data = JSON.parse(localStorage.getItem(storageKey(id)) || '[]');
      return Array.isArray(data) ? data : [];
    } catch (e) {
      return [];
    }
  }
  function saveHistory(id, history) {
    try {
      localStorage.setItem(storageKey(id), JSON.stringify(history.slice(-100)));
    } catch (e) { /* хранилище недоступно, не страшно */ }
  }

  function addBubble(role, text) {
    const el = document.createElement('div');
    el.className = 'msg ' + role;
    el.textContent = text; // textContent, чтобы текст нельзя было превратить в HTML
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return el;
  }

  // Фото на весь экран по клику, закрывается кликом или Escape
  function openLightbox(url, alt) {
    const box = document.createElement('div');
    box.className = 'lightbox';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', alt);
    const img = new Image();
    img.src = url;
    img.alt = alt;
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'lightbox-close';
    close.textContent = '×';
    close.setAttribute('aria-label', t('chat.close'));
    function done() {
      box.remove();
      document.removeEventListener('keydown', onKey);
    }
    function onKey(e) { if (e.key === 'Escape') done(); }
    box.addEventListener('click', done);
    document.addEventListener('keydown', onKey);
    box.append(img, close);
    document.body.appendChild(box);
    close.focus();
  }

  // Сообщение персонажа с фото и подписью
  function addPhotoBubble(url, caption, title) {
    const el = document.createElement('div');
    el.className = 'msg assistant with-photo';
    const img = new Image();
    img.className = 'chat-photo';
    img.alt = title || t('chat.photo_alt');
    img.addEventListener('load', () => { messagesEl.scrollTop = messagesEl.scrollHeight; });
    img.addEventListener('click', () => openLightbox(url, img.alt));
    img.src = url;
    el.appendChild(img);
    if (caption) {
      const c = document.createElement('div');
      c.className = 'photo-caption';
      c.textContent = caption;
      el.appendChild(c);
    }
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return el;
  }

  function renderMessage(m) {
    if (m.image) addPhotoBubble(m.image, m.content, m.photo);
    else addBubble(m.role, m.content);
  }

  function renderChat() {
    messagesEl.innerHTML = '';
    const history = loadHistory(current.id);
    if (history.length === 0) {
      addBubble('assistant', current.greeting);
    } else {
      history.forEach(renderMessage);
    }
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  // Картинка персонажа, а если файла нет, то эмодзи
  function setAvatar(el, character) {
    el.textContent = character.avatar;
    if (!character.image) return;
    const img = new Image();
    img.alt = '';
    img.onload = () => { el.textContent = ''; el.appendChild(img); };
    img.src = character.image;
  }

  function applyHeader() {
    if (!current) {
      headerAvatar.textContent = '💬';
      headerName.textContent = t('chat.pick');
      headerTagline.textContent = '';
      return;
    }
    setAvatar(headerAvatar, current);
    headerName.textContent = current.name;
    headerTagline.textContent = current.tagline;
  }

  function markActive() {
    document.querySelectorAll('.character').forEach((el) => {
      el.classList.toggle('active', !!current && el.dataset.id === current.id);
    });
  }

  function selectCharacter(character) {
    current = character;
    try { history.replaceState(null, '', '?c=' + encodeURIComponent(character.id)); } catch (e) {}
    applyHeader();
    clearBtn.hidden = false;
    input.disabled = false;
    sendBtn.disabled = false;
    app.classList.add('in-chat');
    markActive();
    renderChat();
    input.focus();
  }

  function renderList() {
    listEl.innerHTML = '';
    characters.forEach((c) => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.className = 'character';
      btn.dataset.id = c.id;

      const avatar = document.createElement('div');
      avatar.className = 'avatar';
      setAvatar(avatar, c);

      const text = document.createElement('div');
      const name = document.createElement('div');
      name.className = 'name';
      name.textContent = c.name;
      const tagline = document.createElement('div');
      tagline.className = 'tagline';
      tagline.textContent = c.tagline;
      text.append(name, tagline);

      btn.append(avatar, text);
      btn.addEventListener('click', () => selectCharacter(c));
      li.appendChild(btn);
      listEl.appendChild(li);
    });
    markActive();
  }

  async function loadCharacters() {
    const res = await fetch('/api/characters?lang=' + encodeURIComponent(i18n.lang));
    if (!res.ok) throw new Error('bad status');
    characters = await res.json();
    renderList();
    if (current) {
      // обновляем выбранного персонажа на новом языке; уже начатую переписку не трогаем
      current = characters.find((c) => c.id === current.id) || null;
      applyHeader();
      if (current && loadHistory(current.id).length === 0) renderChat();
    } else {
      applyHeader();
    }
  }

  async function send(text) {
    if (sending || !current) return;
    sending = true;
    sendBtn.disabled = true;

    const characterId = current.id;
    const history = loadHistory(characterId);
    if (history.length === 0) {
      // приветствие тоже часть диалога, чтобы персонаж его «помнил»
      history.push({ role: 'assistant', content: current.greeting });
    }
    history.push({ role: 'user', content: text });
    saveHistory(characterId, history);

    addBubble('user', text);
    const typing = addBubble('assistant', '');
    typing.innerHTML = '<span class="typing"><span></span><span></span><span></span></span>';

    try {
      const res = await fetch('/api/chat?lang=' + encodeURIComponent(i18n.lang), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // модели отправляем только последние сообщения, а список уже показанных фото отдельно (чтобы не повторялись)
        body: JSON.stringify({
          characterId,
          messages: history.slice(-20),
          sentPhotos: history.filter((m) => m.photoId).map((m) => m.photoId),
        }),
      });
      const data = await res.json().catch(() => ({}));
      typing.remove();
      if (!res.ok) throw new Error(data.error || t('chat.reply_error'));

      const entry = { role: 'assistant', content: data.reply };
      if (data.photo) {
        entry.image = data.photo.url;
        entry.photoId = data.photo.id;
        entry.photo = data.photo.title;
      }
      history.push(entry);
      saveHistory(characterId, history);
      if (current && current.id === characterId) {
        renderMessage(entry);
        // фото заблокированы (платная функция): показываем плашку, в историю не сохраняем
        if (data.photoLocked) addBubble('notice', t('chat.photo_locked'));
      }
    } catch (err) {
      typing.remove();
      // сообщение пользователя остаётся в истории; ошибку просто показываем
      if (current && current.id === characterId) addBubble('error', err.message);
    } finally {
      sending = false;
      sendBtn.disabled = false;
      input.focus();
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    autoGrow();
    send(text);
  });

  // Enter отправляет, Shift+Enter делает новую строку
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      form.requestSubmit();
    }
  });
  function autoGrow() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 140) + 'px';
  }
  input.addEventListener('input', autoGrow);

  clearBtn.addEventListener('click', () => {
    if (!current) return;
    if (!confirm(t('chat.clear_confirm'))) return;
    try { localStorage.removeItem(storageKey(current.id)); } catch (e) {}
    renderChat();
  });

  backBtn.addEventListener('click', () => app.classList.remove('in-chat'));

  i18n.onChange(() => {
    loadCharacters().catch(() => {});
  });

  applyHeader();
  loadCharacters()
    .then(() => {
      // Открыли из карточки на главной: chat.html?c=id
      const wanted = new URLSearchParams(location.search).get('c');
      const match = characters.find((c) => c.id === wanted);
      if (match) selectCharacter(match);
    })
    .catch(() => {
      messagesEl.innerHTML = '';
      addBubble('error', t('chat.load_error'));
    });
})();
