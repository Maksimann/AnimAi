// Переводы интерфейса и переключатель языка.
// Чтобы добавить язык: допишите его в SUPPORTED, добавьте словарь в DICT
// (и тексты персонажей в админке), а на сервере добавьте код в util.js и MESSAGES.
(function () {
  const SUPPORTED = ['ru', 'en'];
  const LABELS = { ru: 'RU', en: 'EN' };

  const DICT = {
    ru: {
      'lang.aria': 'Язык',
      'home.title': 'Чат с ИИ-персонажами',
      'home.h1': 'Поговорите с персонажем',
      'home.sub': 'Выберите героя по душе и начните разговор',
      'home.search_ph': 'Найти персонажа или жанр…',
      'home.search_aria': 'Поиск персонажей',
      'home.genres_aria': 'Жанры',
      'home.all': 'Все',
      'home.found': 'Найдено персонажей: {n}',
      'home.none': 'Никого не нашлось. Попробуйте другое имя или жанр.',
      'home.load_error': 'Не удалось загрузить список персонажей. Обновите страницу.',
      'chat.title': 'Чат с персонажем',
      'chat.home': '← На главную',
      'chat.characters': 'Персонажи',
      'chat.pick': 'Выберите персонажа',
      'chat.empty': 'Выберите персонажа слева, чтобы начать разговор.',
      'chat.placeholder': 'Напишите сообщение…',
      'chat.send': 'Отправить',
      'chat.clear': 'Очистить',
      'chat.clear_title': 'Начать диалог заново',
      'chat.clear_confirm': 'Начать диалог с персонажем заново?',
      'chat.back_aria': 'К списку персонажей',
      'chat.load_error': 'Не удалось загрузить список персонажей.',
      'chat.reply_error': 'Не удалось получить ответ.',
      'chat.photo_locked': '🔒 Отправка фото доступна по подписке.',
      'chat.photo_alt': 'Фото',
      'chat.close': 'Закрыть',
    },
    en: {
      'lang.aria': 'Language',
      'home.title': 'AI Character Chat',
      'home.h1': 'Talk to a character',
      'home.sub': 'Pick a hero you like and start a conversation',
      'home.search_ph': 'Search characters or genres…',
      'home.search_aria': 'Search characters',
      'home.genres_aria': 'Genres',
      'home.all': 'All',
      'home.found': 'Characters found: {n}',
      'home.none': 'No one found. Try a different name or genre.',
      'home.load_error': 'Could not load the character list. Please refresh the page.',
      'chat.title': 'Chat with a character',
      'chat.home': '← Home',
      'chat.characters': 'Characters',
      'chat.pick': 'Choose a character',
      'chat.empty': 'Choose a character on the left to start chatting.',
      'chat.placeholder': 'Type a message…',
      'chat.send': 'Send',
      'chat.clear': 'Clear',
      'chat.clear_title': 'Start the conversation over',
      'chat.clear_confirm': 'Start the conversation with this character over?',
      'chat.back_aria': 'Back to characters',
      'chat.load_error': 'Could not load the character list.',
      'chat.reply_error': 'Could not get a reply.',
      'chat.photo_locked': '🔒 Sending photos is available with a subscription.',
      'chat.photo_alt': 'Photo',
      'chat.close': 'Close',
    },
  };

  const STORAGE_KEY = 'lang';
  const listeners = [];

  function detect() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (SUPPORTED.includes(saved)) return saved;
    } catch (e) { /* хранилище недоступно */ }
    // Без сохранённого выбора: английский браузер получает английский, остальные русский
    const nav = String(navigator.language || 'ru').slice(0, 2).toLowerCase();
    return nav === 'en' ? 'en' : 'ru';
  }

  const state = { lang: detect() };

  function t(key, vars) {
    let s = (DICT[state.lang] && DICT[state.lang][key]) || DICT.ru[key] || key;
    if (vars) Object.keys(vars).forEach((k) => { s = s.replace('{' + k + '}', vars[k]); });
    return s;
  }

  function apply() {
    document.documentElement.lang = state.lang;
    const titleKey = document.documentElement.getAttribute('data-title');
    if (titleKey) document.title = t(titleKey);
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    document.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
    document.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = t(el.dataset.i18nTitle); });
    document.querySelectorAll('.lang-switch').forEach((box) => {
      box.setAttribute('aria-label', t('lang.aria'));
      box.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.lang === state.lang)));
    });
  }

  function setLang(lang) {
    if (!SUPPORTED.includes(lang) || lang === state.lang) return;
    state.lang = lang;
    try { localStorage.setItem(STORAGE_KEY, lang); } catch (e) { /* не страшно */ }
    apply();
    listeners.forEach((fn) => fn(lang));
  }

  // Рисуем кнопки RU / EN в каждом контейнере .lang-switch
  function buildSwitchers() {
    document.querySelectorAll('.lang-switch').forEach((box) => {
      box.setAttribute('role', 'group');
      SUPPORTED.forEach((code) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.dataset.lang = code;
        b.textContent = LABELS[code];
        b.addEventListener('click', () => setLang(code));
        box.appendChild(b);
      });
    });
  }

  buildSwitchers();
  apply();

  window.i18n = {
    get lang() { return state.lang; },
    t,
    setLang,
    apply,
    onChange(fn) { listeners.push(fn); },
  };
})();
