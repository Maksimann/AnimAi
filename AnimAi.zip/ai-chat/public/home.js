(function () {
  const t = i18n.t;
  const searchEl = document.getElementById('search');
  const genresEl = document.getElementById('genres');
  const gridEl = document.getElementById('grid');
  const infoEl = document.getElementById('resultsInfo');
  const noResultsEl = document.getElementById('noResults');

  let characters = [];
  let loadFailed = false;
  let activeGenre = ''; // пусто = все жанры

  const norm = (s) => String(s || '').toLowerCase().replace(/ё/g, 'е').trim();

  // Совпадает ли персонаж с текстом поиска: имя, подпись или жанр
  function matchesQuery(c, q) {
    if (!q) return true;
    const hay = norm([c.name, c.tagline, ...c.genres].join(' '));
    return q.split(/\s+/).every((word) => hay.includes(word));
  }

  function buildCard(c, q) {
    const a = document.createElement('a');
    a.className = 'card';
    a.href = 'chat.html?c=' + encodeURIComponent(c.id);

    const imgWrap = document.createElement('div');
    imgWrap.className = 'card-img';
    const emoji = document.createElement('span');
    emoji.className = 'card-emoji';
    emoji.textContent = c.avatar;
    imgWrap.appendChild(emoji);
    if (c.image) {
      const img = new Image();
      img.alt = c.name;
      img.loading = 'lazy';
      img.onerror = () => img.remove(); // если файла нет, остаётся эмодзи
      img.src = c.image;
      imgWrap.appendChild(img);
    }

    const body = document.createElement('div');
    body.className = 'card-body';
    const name = document.createElement('div');
    name.className = 'card-name';
    name.textContent = c.name;
    const tagline = document.createElement('div');
    tagline.className = 'card-tagline';
    tagline.textContent = c.tagline;
    const tags = document.createElement('div');
    tags.className = 'card-genres';
    c.genres.forEach((g) => {
      const tag = document.createElement('span');
      tag.className = 'tag';
      if (norm(g) === norm(activeGenre) || (q && norm(g).includes(q))) tag.classList.add('match');
      tag.textContent = g;
      tags.appendChild(tag);
    });

    body.append(name, tagline, tags);
    a.append(imgWrap, body);
    return a;
  }

  function render() {
    const q = norm(searchEl.value);
    const list = characters.filter(
      (c) => (!activeGenre || c.genres.some((g) => norm(g) === norm(activeGenre))) && matchesQuery(c, q)
    );

    gridEl.innerHTML = '';
    list.forEach((c) => gridEl.appendChild(buildCard(c, q)));
    noResultsEl.hidden = loadFailed || list.length > 0;
    if (loadFailed) infoEl.textContent = t('home.load_error');
    else infoEl.textContent = list.length > 0 ? t('home.found', { n: list.length }) : '';
    document.querySelectorAll('.chip').forEach((chip) => {
      chip.classList.toggle('active', chip.dataset.genre === activeGenre);
    });
  }

  function renderGenres() {
    // Список жанров собирается автоматически из персонажей на текущем языке
    const all = [...new Set(characters.flatMap((c) => c.genres))]
      .sort((a, b) => a.localeCompare(b, i18n.lang));
    genresEl.innerHTML = '';
    [''].concat(all).forEach((g) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'chip';
      chip.dataset.genre = g;
      chip.textContent = g || t('home.all');
      chip.addEventListener('click', () => {
        activeGenre = g === activeGenre ? '' : g;
        render();
      });
      genresEl.appendChild(chip);
    });
  }

  async function load() {
    try {
      const res = await fetch('/api/characters?lang=' + encodeURIComponent(i18n.lang));
      if (!res.ok) throw new Error('bad status');
      const data = await res.json();
      characters = data.map((c) => ({ ...c, genres: c.genres || [] }));
      loadFailed = false;
    } catch (e) {
      characters = [];
      loadFailed = true;
    }
    // названия жанров зависят от языка, поэтому выбранный жанр сбрасываем
    if (!characters.some((c) => c.genres.some((g) => norm(g) === norm(activeGenre)))) activeGenre = '';
    renderGenres();
    render();
  }

  searchEl.addEventListener('input', render);
  i18n.onChange(load);
  load();
})();
