(function () {
  const $ = (id) => document.getElementById(id);
  const loginView = $('loginView'), mainView = $('mainView');
  const listEl = $('list'), editor = $('editor'), emptyState = $('emptyState');
  const f = {
    id: $('f_id'), name: $('f_name'), tagline: $('f_tagline'), avatar: $('f_avatar'),
    genres: $('f_genres'), greeting: $('f_greeting'), prompt: $('f_prompt'),
    published: $('f_published'), order: $('f_order'), file: $('f_file'),
    enName: $('f_en_name'), enTagline: $('f_en_tagline'), enGenres: $('f_en_genres'), enGreeting: $('f_en_greeting'),
  };

  const photosBox = $('photosBox'), photoGrid = $('photoGrid'), photoStatus = $('photoStatus');
  const photoCount = $('photoCount'), photoFile = $('photoFile');
  const MAX_PHOTOS = 20, MAX_BYTES = 3 * 1024 * 1024;

  let photoList = [];
  let characters = [];
  let currentId = null;   // id редактируемого персонажа, null = новый
  let imageValue = '';    // текущее значение поля image

  async function api(method, url, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && !url.endsWith('/login')) { showLogin(); throw new Error('Нужно войти.'); }
    if (!res.ok) throw new Error(data.error || 'Ошибка ' + res.status);
    return data;
  }

  function showLogin() {
    mainView.hidden = true;
    loginView.hidden = false;
    $('password').focus();
  }
  function showMain() {
    loginView.hidden = true;
    mainView.hidden = false;
  }

  // ---------- вход ----------
  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('loginError').textContent = '';
    try {
      await api('POST', '/api/admin/login', { password: $('password').value });
      $('password').value = '';
      await loadList();
      showMain();
    } catch (err) {
      $('loginError').textContent = err.message;
    }
  });
  $('logoutBtn').addEventListener('click', async () => {
    try { await api('POST', '/api/admin/logout', {}); } catch (e) {}
    showLogin();
  });

  // ---------- список ----------
  function setAvatar(el, c) {
    el.textContent = c.avatar;
    if (!c.image) return;
    const img = new Image();
    img.alt = '';
    img.onload = () => { el.textContent = ''; el.appendChild(img); };
    img.src = c.image;
  }

  function renderList() {
    listEl.innerHTML = '';
    characters.forEach((c) => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'admin-item' + (c.id === currentId ? ' active' : '') + (c.published ? '' : ' hidden-char');

      const av = document.createElement('div');
      av.className = 'avatar';
      setAvatar(av, c);

      const text = document.createElement('div');
      const name = document.createElement('div');
      name.className = 'name';
      name.textContent = c.name;
      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.textContent = c.id;
      text.append(name, meta);

      btn.append(av, text);
      if (!c.published) {
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.textContent = 'скрыт';
        btn.appendChild(badge);
      }
      btn.addEventListener('click', () => openEditor(c));
      li.appendChild(btn);
      listEl.appendChild(li);
    });
  }

  async function loadList() {
    characters = await api('GET', '/api/admin/characters');
    renderList();
  }

  // ---------- форма ----------
  function setPreview() {
    const box = $('preview');
    box.innerHTML = '';
    const emoji = document.createElement('span');
    emoji.textContent = f.avatar.value.trim() || '🖼️';
    box.appendChild(emoji);
    if (imageValue) {
      const img = new Image();
      img.alt = '';
      img.onerror = () => img.remove();
      img.src = imageValue;
      box.appendChild(img);
    }
    $('removeImageBtn').hidden = !imageValue;
  }

  function clearMessages() {
    $('formError').textContent = '';
    $('formOk').textContent = '';
    $('uploadError').textContent = '';
  }

  function openEditor(c) {
    clearMessages();
    currentId = c ? c.id : null;
    emptyState.hidden = true;
    editor.hidden = false;
    $('editorTitle').textContent = c ? 'Редактирование: ' + c.name : 'Новый персонаж';
    f.id.value = c ? c.id : '';
    f.id.disabled = !!c;
    f.name.value = c ? c.name : '';
    f.tagline.value = c ? c.tagline : '';
    f.avatar.value = c ? c.avatar : '';
    f.genres.value = c ? c.genres.join(', ') : '';
    f.greeting.value = c ? c.greeting : '';
    f.prompt.value = c ? c.systemPrompt : '';
    const en = (c && c.translations && c.translations.en) || {};
    f.enName.value = en.name || '';
    f.enTagline.value = en.tagline || '';
    f.enGenres.value = (en.genres || []).join(', ');
    f.enGreeting.value = en.greeting || '';
    f.published.checked = c ? c.published : true;
    f.order.value = c ? c.sortOrder : '';
    imageValue = c ? c.image : '';
    $('deleteBtn').hidden = !c;
    setPreview();
    renderList();
    photosBox.hidden = !c; // фото можно добавлять только уже сохранённому персонажу
    if (c) loadPhotos(c.id); else photoList = [];
    editor.scrollIntoView({ block: 'start' });
  }

  // ---------- фото для чата ----------
  const photosUrl = (id) => '/api/admin/characters/' + encodeURIComponent(id) + '/photos';

  async function loadPhotos(id) {
    photoGrid.innerHTML = '';
    photoStatus.textContent = '';
    try {
      const list = await api('GET', photosUrl(id));
      if (currentId !== id) return; // за это время открыли другого персонажа
      photoList = list;
      renderPhotos();
    } catch (err) {
      photoStatus.textContent = err.message;
    }
  }

  function renderPhotos() {
    photoCount.textContent = photoList.length + ' / ' + MAX_PHOTOS;
    photoGrid.innerHTML = '';
    photoList.forEach((p) => photoGrid.appendChild(photoCard(p)));
  }

  function labeled(text, control) {
    const label = document.createElement('label');
    label.append(text, control);
    return label;
  }

  function photoCard(p) {
    const card = document.createElement('div');
    card.className = 'photo-card';

    const img = new Image();
    img.className = 'photo-thumb';
    img.alt = p.title;
    img.src = p.url;

    const title = document.createElement('input');
    title.value = p.title;
    title.maxLength = 60;
    const tags = document.createElement('input');
    tags.value = p.tags.join(', ');
    tags.placeholder = 'пляж, море, beach, sea';
    const desc = document.createElement('textarea');
    desc.rows = 2;
    desc.maxLength = 300;
    desc.value = p.description;
    desc.placeholder = 'Что на фото (по желанию): помогает персонажу точнее подписать';

    const row = document.createElement('div');
    row.className = 'row';
    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'btn small primary';
    save.textContent = 'Сохранить';
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'btn small danger';
    del.textContent = 'Удалить';
    const state = document.createElement('span');
    state.className = 'state';
    row.append(save, del, state);

    save.addEventListener('click', async () => {
      state.className = 'state';
      state.textContent = '…';
      try {
        const saved = await api('PUT', '/api/admin/photos/' + p.id, {
          title: title.value, tags: tags.value.split(','), description: desc.value,
        });
        Object.assign(p, saved);
        tags.value = saved.tags.join(', ');
        state.className = 'state ok';
        state.textContent = 'Сохранено';
      } catch (err) {
        state.className = 'state err';
        state.textContent = err.message;
      }
    });

    del.addEventListener('click', async () => {
      if (!confirm('Удалить это фото?')) return;
      try {
        await api('DELETE', '/api/admin/photos/' + p.id);
        photoList = photoList.filter((x) => x.id !== p.id);
        renderPhotos();
      } catch (err) {
        state.className = 'state err';
        state.textContent = err.message;
      }
    });

    card.append(img, labeled('Тема', title), labeled('Ключевые слова через запятую', tags), labeled('Описание', desc), row);
    return card;
  }

  $('photoUploadBtn').addEventListener('click', () => photoFile.click());
  photoFile.addEventListener('change', async () => {
    const files = [...photoFile.files];
    photoFile.value = '';
    const id = currentId;
    if (!id || files.length === 0) return;
    const errors = [];
    let uploaded = 0;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      photoStatus.textContent = 'Загрузка ' + (i + 1) + ' из ' + files.length + '…';
      try {
        if (file.size > MAX_BYTES) throw new Error('файл больше 3 МБ');
        const res = await fetch(photosUrl(id) + '?name=' + encodeURIComponent(file.name), {
          method: 'POST', headers: { 'Content-Type': file.type }, body: file,
        });
        const data = await res.json().catch(() => ({}));
        if (res.status === 401) { showLogin(); return; }
        if (!res.ok) throw new Error(data.error || 'ошибка ' + res.status);
        if (currentId === id) { photoList.push(data); renderPhotos(); }
        uploaded++;
      } catch (err) {
        errors.push(file.name + ': ' + err.message);
      }
    }
    photoStatus.textContent = (uploaded ? 'Загружено: ' + uploaded + '. Проверьте темы и ключевые слова. ' : '') +
      (errors.length ? 'Не загружено: ' + errors.join('; ') : '');
  });

  $('newBtn').addEventListener('click', () => openEditor(null));
  f.avatar.addEventListener('input', setPreview);

  // ---------- картинка ----------
  $('uploadBtn').addEventListener('click', () => f.file.click());
  f.file.addEventListener('change', async () => {
    const file = f.file.files[0];
    f.file.value = '';
    if (!file) return;
    $('uploadError').textContent = '';
    if (file.size > 3 * 1024 * 1024) { $('uploadError').textContent = 'Файл больше 3 МБ.'; return; }
    try {
      const res = await fetch('/api/admin/upload', { method: 'POST', headers: { 'Content-Type': file.type }, body: file });
      const data = await res.json().catch(() => ({}));
      if (res.status === 401) { showLogin(); return; }
      if (!res.ok) throw new Error(data.error || 'Не удалось загрузить.');
      imageValue = data.url;
      setPreview();
      $('formOk').textContent = 'Картинка загружена. Нажмите «Сохранить», чтобы применить.';
    } catch (err) {
      $('uploadError').textContent = err.message;
    }
  });
  $('removeImageBtn').addEventListener('click', () => { imageValue = ''; setPreview(); });

  // ---------- сохранение и удаление ----------
  editor.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearMessages();
    const body = {
      id: f.id.value.trim(),
      name: f.name.value,
      tagline: f.tagline.value,
      avatar: f.avatar.value,
      image: imageValue,
      genres: f.genres.value.split(','),
      greeting: f.greeting.value,
      systemPrompt: f.prompt.value,
      translations: {
        en: {
          name: f.enName.value,
          tagline: f.enTagline.value,
          genres: f.enGenres.value.split(','),
          greeting: f.enGreeting.value,
        },
      },
      published: f.published.checked,
    };
    if (f.order.value !== '') body.sortOrder = Number(f.order.value);

    $('saveBtn').disabled = true;
    try {
      const saved = currentId
        ? await api('PUT', '/api/admin/characters/' + encodeURIComponent(currentId), body)
        : await api('POST', '/api/admin/characters', body);
      await loadList();
      openEditor(characters.find((c) => c.id === saved.id) || saved);
      $('formOk').textContent = 'Сохранено.';
    } catch (err) {
      $('formError').textContent = err.message;
    } finally {
      $('saveBtn').disabled = false;
    }
  });

  $('deleteBtn').addEventListener('click', async () => {
    if (!currentId) return;
    const c = characters.find((x) => x.id === currentId);
    if (!confirm('Удалить персонажа «' + (c ? c.name : currentId) + '»? Это нельзя отменить.')) return;
    try {
      await api('DELETE', '/api/admin/characters/' + encodeURIComponent(currentId));
      currentId = null;
      editor.hidden = true;
      photosBox.hidden = true;
      emptyState.hidden = false;
      await loadList();
    } catch (err) {
      $('formError').textContent = err.message;
    }
  });

  // ---------- старт ----------
  (async function init() {
    try {
      await api('GET', '/api/admin/me');
      await loadList();
      showMain();
    } catch (err) {
      showLogin();
      if (/выключена/.test(err.message)) $('loginError').textContent = err.message;
    }
  })();
})();
